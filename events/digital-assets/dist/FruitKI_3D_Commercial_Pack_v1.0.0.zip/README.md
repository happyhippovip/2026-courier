# FruitKI 3D Commercial Pack v1.0.0

Thank you for your purchase! Drag the `.tscn` scene files into your Godot 4.x project.
See `COMMERCIAL_LICENSE_AGREEMENT.md` for commercial royalty-free license terms.
