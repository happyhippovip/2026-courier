/**
 * Execution-truth helpers for the Operations Studio.
 *
 * The studio renders only an explicit execution_class supplied by the Courier
 * state API.  It deliberately does not infer an execution class from an agent
 * id, display name, task name, or UI animation.
 */
export const EXECUTION_CLASSES = Object.freeze([
  'REAL_CODEX_CLI',
  'DETERMINISTIC_CODEX',
  'REAL_ANTIGRAVITY',
  'DETERMINISTIC_ANTIGRAVITY',
  'FALLBACK',
  'SIMULATED_VISUAL',
  'REGISTERED',
  'UNKNOWN',
  'WAITING_FOR_HUMAN',
  'BLOCKED',
]);

const KNOWN_EXECUTION_CLASSES = new Set(EXECUTION_CLASSES);

/**
 * Return only a machine-provided, supported execution class.
 * Missing or malformed evidence is visibly UNKNOWN rather than guessed.
 */
export function resolveExecutionTruth(agentState) {
  const executionClass = agentState?.execution_class;
  return typeof executionClass === 'string' && KNOWN_EXECUTION_CLASSES.has(executionClass)
    ? executionClass
    : 'UNKNOWN';
}

/**
 * A missing decision is not an approval.  This is a display label, not a
 * generated workflow decision.
 */
export function resolveDecisionTruth(busState) {
  const decision = busState?.last_decision;
  return typeof decision === 'string' && decision.trim() ? decision : 'NO_DECISION';
}

/**
 * A human-gate decision is valid only when the API has already matched it to
 * the currently active gate by workflow_id *and* correlation_id.  The browser
 * does not attempt that association itself and never falls back to a global
 * latest decision.
 */
export function resolveGateDecisionTruth(busState) {
  const gate = busState?.active_human_gate;
  const decision = busState?.gate_decision;
  if (!gate?.provenance_complete || !gate.workflow_id || !gate.correlation_id) {
    return 'NO_DECISION';
  }
  if (
    decision?.workflow_id !== gate.workflow_id
    || decision?.correlation_id !== gate.correlation_id
  ) {
    return 'NO_DECISION';
  }
  return typeof decision.status === 'string' && decision.status.trim()
    ? decision.status
    : 'NO_DECISION';
}

/** Deterministic, machine-state-derived speech; no model narration. */
export function resolveSpeechBubble(agentId, agentState, busState) {
  const state = typeof agentState?.state === 'string' ? agentState.state : 'UNKNOWN';
  const task = typeof agentState?.task === 'string' && agentState.task ? agentState.task : null;
  if (agentId === 'agent-snitch') {
    if (state === 'EXPECTED_LONG_RUNNING') return 'The Studio server is intentionally running continuously. No action needed.';
    if (state === 'SLOW_BUT_PROGRESSING') return 'This task is slow, but recent progress is recorded.';
    if (state === 'ALERT_SENT' || state === 'STALLED') return 'No recent progress was recorded. I informed Chief.';
    if (state === 'WAITING_FOR_HUMAN') return 'A human gate is active. I am monitoring safely.';
    if (state === 'MONITORING') return 'I am watching runtime evidence. Everything is within threshold.';
  }
  if (agentId === 'agent-chief-commander' && state === 'RUNNING') {
    return 'A workflow is active. I am waiting for machine-recorded results.';
  }
  if (agentId === 'agent-courier-relay' && task) return `Courier is handling: ${task}.`;
  if (agentId === 'agent-academy-teacher' && state === 'PENDING_REVIEW') return 'I am waiting for the next safe lesson window.';
  if (busState?.human_gate && (agentId === 'agent-chief-commander' || state.includes('BLOCKED'))) {
    return 'This workflow is waiting for verified human approval.';
  }
  if (task) return `${state}: ${task}.`;
  return state === 'UNKNOWN' ? 'No current machine evidence is available.' : `${state}: no task is currently recorded.`;
}

/**
 * Return a real correlation id only.  The caller may display a neutral label
 * for null, but must never generate an identifier in the browser.
 */
export function resolveCorrelationTruth(busState) {
  const correlationId = busState?.correlation_id;
  return typeof correlationId === 'string'
    && correlationId.trim()
    && correlationId !== 'UNKNOWN'
    && correlationId !== 'NO_ACTIVE_WORKFLOW'
    ? correlationId
    : null;
}

export function executionBadgeLabel(executionClass) {
  const iconByClass = {
    REAL_CODEX_CLI: '🟢',
    REAL_ANTIGRAVITY: '🟢',
    DETERMINISTIC_CODEX: '🟡',
    DETERMINISTIC_ANTIGRAVITY: '🟡',
    FALLBACK: '🟠',
    SIMULATED_VISUAL: '🟣',
    REGISTERED: '🔵',
    WAITING_FOR_HUMAN: '🟠',
    BLOCKED: '🔴',
    UNKNOWN: '⚪',
  };
  return `${iconByClass[executionClass] || '⚪'} ${executionClass}`;
}

/**
 * Resolve Update Steward truth strictly from backend state evidence.
 * Missing evidence returns neutral UNKNOWN / null values, never fabricated strings.
 */
export function resolveStewardTruth(stateData) {
  const agents = stateData?.agents || {};
  const steward = agents['agent-update-steward'];
  const snapshot = stateData?.context_snapshot;

  const state = typeof steward?.state === 'string' && steward.state.trim()
    ? steward.state
    : (snapshot ? 'CONTEXT CURRENT' : 'UNKNOWN');

  const contextVersion = typeof snapshot?.context_version === 'number'
    ? snapshot.context_version
    : (typeof stateData?.bus?.context_version === 'number' && stateData.bus.context_version > 0
        ? stateData.bus.context_version
        : null);

  const prevVersion = typeof snapshot?.previous_snapshot_version === 'number'
    ? snapshot.previous_snapshot_version
    : null;

  const snapshotHash = typeof snapshot?.snapshot_hash === 'string' && snapshot.snapshot_hash.length >= 8
    ? snapshot.snapshot_hash
    : (typeof stateData?.bus?.snapshot_hash === 'string' && stateData.bus.snapshot_hash !== 'NONE'
        ? stateData.bus.snapshot_hash
        : null);

  const lastRefresh = typeof snapshot?.generated_at === 'string'
    ? snapshot.generated_at
    : (typeof steward?.updated_at === 'string' ? steward.updated_at : null);

  const changedItems = Array.isArray(snapshot?.changed_since_previous_snapshot)
    ? snapshot.changed_since_previous_snapshot
    : [];

  const repositories = typeof snapshot?.repositories === 'object' && snapshot.repositories !== null
    ? snapshot.repositories
    : {};

  const nextAction = typeof steward?.next_action === 'string' && steward.next_action.trim()
    ? steward.next_action
    : (steward?.last_action || null);

  const staleTasks = steward?.blocked || state === 'REFRESH REQUIRED'
    ? 'CONTEXT_REFRESH_REQUIRED'
    : 'NONE';

  return {
    state,
    context_version: contextVersion,
    previous_version: prevVersion,
    snapshot_hash: snapshotHash,
    last_refresh: lastRefresh,
    changed_items: changedItems,
    repositories,
    next_action: nextAction,
    stale_tasks: staleTasks,
    progress: typeof steward?.progress === 'number' ? steward.progress : (snapshot ? 1.0 : 0.0),
    task: steward?.task || (contextVersion ? `Context v${contextVersion}` : 'Standby'),
  };
}

/**
 * Resolve Chief wait-state from explicit machine evidence only.
 */
export function resolveChiefWaitState(stateData) {
  const agents = stateData?.agents || {};
  const bus = stateData?.bus || {};

  const chief = agents['agent-chief-commander'];
  const ag = agents['agent-antigravity-bridge'];
  const cdx = agents['agent-codex-bridge'];
  const curator = agents['agent-thought-curator'];

  // 1. Human Gate required
  if (
    bus.human_gate ||
    chief?.state === 'BLOCKED_HUMAN_GATE' ||
    chief?.state === 'BLOCKED_POLICY_CONFLICT' ||
    ag?.state === 'BLOCKED_HUMAN_GATE' ||
    cdx?.state === 'BLOCKED_HUMAN_GATE' ||
    curator?.state === 'CONFLICT' ||
    curator?.state === 'BLOCKED'
  ) {
    return 'CHIEF WAITING FOR HUMAN';
  }

  // 2. Active worker running
  if (ag?.state === 'RUNNING') {
    return 'CHIEF WAITING FOR ANTIGRAVITY';
  }
  if (cdx?.state === 'RUNNING') {
    return 'CHIEF WAITING FOR CODEX';
  }

  // 3. Worker finished, awaiting review
  if (ag?.state === 'AWAITING_CHIEF_REVIEW') {
    return 'RESULT RECEIVED FROM ANTIGRAVITY';
  }
  if (cdx?.state === 'AWAITING_CHIEF_REVIEW') {
    return 'RESULT RECEIVED FROM CODEX';
  }

  // 4. Chief evaluating or planning
  if (chief?.state === 'REVIEWING' || chief?.state === 'EVALUATING') {
    return 'REVIEWING RESULT';
  }
  if (chief?.state === 'PLANNING' || curator?.state === 'SENT TO CHIEF') {
    return 'PLANNING NEXT TASK';
  }

  // 5. Next task ready
  if (bus.is_locked && bus.last_decision === 'ACCEPTED') {
    return 'NEXT TASK READY';
  }

  // 6. Idle or Unknown
  if (!bus.is_locked && (!bus.active_workflow || bus.active_workflow === 'IDLE_MONITORING')) {
    return 'IDLE';
  }

  return 'UNKNOWN';
}

/**
 * Validate that a returned result strictly matches the expected workflow and correlation.
 * Rejects cross-thread and mismatched correlations.
 */
export function validateThreadAssociation(resultEnvelope, expectedWorkflowId, expectedCorrelationId) {
  if (!resultEnvelope || typeof resultEnvelope !== 'object') return false;

  const resCorr = resultEnvelope.correlation_id;
  const resWf = resultEnvelope.payload?.workflow_id || resultEnvelope.workflow_id;

  if (expectedCorrelationId && resCorr && resCorr !== expectedCorrelationId) {
    return false;
  }

  if (expectedWorkflowId && resWf && resWf !== expectedWorkflowId) {
    return false;
  }

  return true;
}

/**
 * Extract structured bounded thread context metadata from state data.
 */
export function resolveThreadContext(stateData) {
  const bus = stateData?.bus || {};
  const agents = stateData?.agents || {};
  const snapshot = stateData?.context_snapshot;

  const correlationId = resolveCorrelationTruth(bus);
  const workflowId = typeof bus.active_workflow === 'string' && bus.active_workflow !== 'IDLE_MONITORING'
    ? bus.active_workflow
    : null;

  // Identify active worker
  let senderAgentId = null;
  let senderAgentType = null;
  let currentTask = null;

  const ag = agents['agent-antigravity-bridge'];
  const cdx = agents['agent-codex-bridge'];
  const chief = agents['agent-chief-commander'];

  if (ag && (ag.state === 'RUNNING' || ag.state === 'AWAITING_CHIEF_REVIEW')) {
    senderAgentId = ag.id || 'agent-antigravity-bridge';
    senderAgentType = 'antigravity';
    currentTask = ag.task || null;
  } else if (cdx && (cdx.state === 'RUNNING' || cdx.state === 'AWAITING_CHIEF_REVIEW')) {
    senderAgentId = cdx.id || 'agent-codex-bridge';
    senderAgentType = 'codex';
    currentTask = cdx.task || null;
  } else if (chief && chief.task) {
    senderAgentId = chief.id || 'agent-chief-commander';
    senderAgentType = 'chief';
    currentTask = chief.task;
  }

  const waitingFor = resolveChiefWaitState(stateData);

  return {
    workflow_id: workflowId,
    correlation_id: correlationId,
    conversation_thread_id: correlationId,
    task_id: currentTask,
    sender_agent_id: senderAgentId,
    sender_agent_type: senderAgentType,
    recipient_agent_id: 'agent-chief-commander',
    waiting_for: waitingFor,
    context_version: typeof snapshot?.context_version === 'number'
      ? snapshot.context_version
      : (typeof bus.context_version === 'number' && bus.context_version > 0 ? bus.context_version : null),
    context_snapshot_hash: snapshot?.snapshot_hash || (bus.snapshot_hash !== 'NONE' ? bus.snapshot_hash : null),
    is_locked: Boolean(bus.is_locked),
    last_decision: resolveDecisionTruth(bus),
  };
}

/**
 * Resolve Academy Teacher (Agentenlehrer) truth strictly from backend state evidence.
 * Clearly distinguishes SCHEDULE READY from RESEARCH RUNNING without guessing.
 */
export function resolveTeacherTruth(stateData) {
  const teacher = stateData?.agents?.['agent-academy-teacher'];
  if (!teacher) {
    return {
      state: 'UNKNOWN',
      schedule_status: 'UNKNOWN',
      last_school_time: null,
      next_school_time: null,
      lessons_today: null,
      latest_lesson: null,
      latest_lesson_status: null,
      pending_lessons: null,
      opportunities_found: null,
      affected_agents: null,
      current_topic: null,
      next_action: null,
      academy_enabled: null,
      school_window_minutes: null,
      eligible_agents: null,
      opportunity_candidates: null,
      progress: null,
      visual_metadata: {
        name: 'AGENTENLEHRER',
        props: ['teacher_hat', 'glasses', 'teacher_pointer'],
        role_label: 'SYSTEM LEARNING + IMPROVEMENT',
      },
    };
  }

  const state = typeof teacher.state === 'string' && teacher.state.trim()
    ? teacher.state
    : 'UNKNOWN';

  const nextSchoolTime = typeof teacher.next_school_time === 'string' && teacher.next_school_time.trim()
    ? teacher.next_school_time
    : null;

  // A schedule is ready only if the backend has supplied a next school time.
  // An absent teacher state never becomes a visual research/schedule claim.
  const scheduleStatus = state === 'RESEARCHING'
    ? 'RESEARCH RUNNING'
    : (nextSchoolTime ? 'SCHEDULE READY' : 'UNKNOWN');

  return {
    state,
    schedule_status: scheduleStatus,
    last_school_time: typeof teacher.last_school_time === 'string' ? teacher.last_school_time : null,
    next_school_time: nextSchoolTime,
    lessons_today: Number.isFinite(teacher.lessons_today) ? teacher.lessons_today : null,
    latest_lesson: typeof teacher.latest_lesson === 'string' ? teacher.latest_lesson : null,
    latest_lesson_status: typeof teacher.latest_lesson_status === 'string' ? teacher.latest_lesson_status : null,
    pending_lessons: Array.isArray(teacher.pending_lessons) ? teacher.pending_lessons : null,
    opportunities_found: Number.isFinite(teacher.opportunities_found) ? teacher.opportunities_found : null,
    affected_agents: Array.isArray(teacher.affected_agents) ? teacher.affected_agents : null,
    current_topic: typeof teacher.current_topic === 'string' ? teacher.current_topic : null,
    next_action: typeof teacher.next_action === 'string'
      ? teacher.next_action
      : (typeof teacher.last_action === 'string' ? teacher.last_action : null),
    academy_enabled: typeof stateData?.academy_config?.academy_enabled === 'boolean'
      ? stateData.academy_config.academy_enabled
      : null,
    school_window_minutes: Number.isFinite(stateData?.academy_config?.academy_window_minutes)
      ? stateData.academy_config.academy_window_minutes
      : null,
    eligible_agents: Array.isArray(teacher.eligible_agents) ? teacher.eligible_agents : null,
    opportunity_candidates: Array.isArray(teacher.opportunity_candidates) ? teacher.opportunity_candidates : null,
    progress: Number.isFinite(teacher.progress) ? teacher.progress : null,
    visual_metadata: teacher.visual_metadata || {
      name: 'AGENTENLEHRER',
      props: ['teacher_hat', 'glasses', 'teacher_pointer'],
      role_label: 'SYSTEM LEARNING + IMPROVEMENT',
    },
  };
}

/**
 * Resolve Academy Director (Schuldirektor) truth strictly from backend state evidence.
 */
export function resolveDirectorTruth(stateData) {
  const director = stateData?.agents?.['agent-academy-director'];
  if (!director) {
    return {
      state: 'UNKNOWN',
      lessons_reviewed: null,
      lessons_approved: null,
      lessons_rejected: null,
      tests_required: null,
      evals_passed: null,
      evals_failed: null,
      rule_violations: null,
      measured_savings: { minutes_saved: null, cost_saved_eur: null },
      next_action: null,
      progress: null,
      visual_metadata: {
        name: 'SCHULDIREKTOR',
        role_label: 'ACADEMY GOVERNANCE + EVALUATION',
      },
    };
  }

  const state = typeof director.state === 'string' && director.state.trim()
    ? director.state
    : 'UNKNOWN';

  return {
    state,
    lessons_reviewed: Number.isFinite(director.lessons_reviewed) ? director.lessons_reviewed : null,
    lessons_approved: Number.isFinite(director.lessons_approved) ? director.lessons_approved : null,
    lessons_rejected: Number.isFinite(director.lessons_rejected) ? director.lessons_rejected : null,
    tests_required: Number.isFinite(director.tests_required) ? director.tests_required : null,
    evals_passed: Number.isFinite(director.evals_passed) ? director.evals_passed : null,
    evals_failed: Number.isFinite(director.evals_failed) ? director.evals_failed : null,
    rule_violations: Number.isFinite(director.rule_violations) ? director.rule_violations : null,
    measured_savings: {
      minutes_saved: Number.isFinite(director.measured_savings?.minutes_saved)
        ? director.measured_savings.minutes_saved
        : null,
      cost_saved_eur: Number.isFinite(director.measured_savings?.cost_saved_eur)
        ? director.measured_savings.cost_saved_eur
        : null,
    },
    next_action: typeof director.next_action === 'string'
      ? director.next_action
      : (typeof director.last_action === 'string' ? director.last_action : null),
    progress: Number.isFinite(director.progress) ? director.progress : null,
    visual_metadata: director.visual_metadata || {
      name: 'SCHULDIREKTOR',
      role_label: 'ACADEMY GOVERNANCE + EVALUATION',
    },
  };
}

/**
 * Resolve Academy economic improvement metrics strictly from evidence.
 * Never fabricates earned revenue; reports NOT_VERIFIED / UNKNOWN if absent.
 */
export function resolveAcademyEconomics(stateData) {
  const econ = stateData?.academy?.economics || stateData?.academy || {};
  const director = stateData?.agents?.['agent-academy-director'];

  const measuredMinSaved = Number.isFinite(econ.measured_minutes_saved)
    ? econ.measured_minutes_saved
    : (Number.isFinite(director?.measured_savings?.minutes_saved) ? director.measured_savings.minutes_saved : null);

  const measuredCostSaved = Number.isFinite(econ.measured_cost_saved_eur)
    ? econ.measured_cost_saved_eur
    : (Number.isFinite(director?.measured_savings?.cost_saved_eur) ? director.measured_savings.cost_saved_eur : null);

  const totalLessonsAdopted = Number.isFinite(econ.total_lessons_adopted)
    ? econ.total_lessons_adopted
    : null;

  const opportunitiesTested = Number.isFinite(econ.opportunities_tested)
    ? econ.opportunities_tested
    : null;

  const evalsPassed = Number.isFinite(director?.evals_passed) ? director.evals_passed : null;
  const evalsFailed = Number.isFinite(director?.evals_failed) ? director.evals_failed : null;
  const totalEvals = evalsPassed !== null && evalsFailed !== null ? evalsPassed + evalsFailed : null;
  const evalPassRate = totalEvals && totalEvals > 0 ? `${Math.round((evalsPassed / totalEvals) * 100)}%` : 'UNKNOWN';

  const revenueEvidence = typeof econ.revenue_evidence === 'string'
    ? econ.revenue_evidence
    : 'UNKNOWN';

  return {
    measured_minutes_saved: measuredMinSaved,
    measured_cost_saved_eur: measuredCostSaved,
    lessons_adopted: totalLessonsAdopted,
    opportunities_tested: opportunitiesTested,
    eval_pass_rate: evalPassRate,
    revenue_evidence: revenueEvidence,
    truth_label: 'OPPORTUNITY != REVENUE (MEASURED SAVINGS ONLY)',
  };
}

/**
 * Resolve bounded Academy structured evidence (config, lessons, opportunities, evaluations).
 */
export function resolveAcademySummary(stateData) {
  const academy = stateData?.academy;
  const config = academy?.config;
  const lessons = Array.isArray(academy?.lessons) ? academy.lessons : null;
  const opportunities = Array.isArray(academy?.opportunities) ? academy.opportunities : null;
  const evaluations = Array.isArray(academy?.evaluations) ? academy.evaluations : null;

  return {
    is_enabled: typeof config?.academy_enabled === 'boolean' ? config.academy_enabled : null,
    timezone: typeof config?.academy_timezone === 'string' ? config.academy_timezone : null,
    daily_time: typeof config?.academy_daily_time === 'string' ? config.academy_daily_time : null,
    window_minutes: Number.isFinite(config?.academy_window_minutes) ? config.academy_window_minutes : null,
    lessons_count: lessons?.length ?? null,
    recent_lessons: lessons,
    opportunities_count: opportunities?.length ?? null,
    recent_opportunities: opportunities,
    evaluations_count: evaluations?.length ?? null,
    recent_evaluations: evaluations,
  };
}

/**
 * Resolve SNITCH 2.0 runtime watchdog truth strictly from evidence.
 */
export function resolveSnitchTruth(stateData) {
  const snitch = stateData?.snitch || stateData?.agents?.['agent-snitch'] || {};
  const incidents = Array.isArray(stateData?.incidents) ? stateData.incidents : [];
  const latestAlert = stateData?.runtime_alert;

  const state = typeof snitch.state === 'string' && snitch.state.trim()
    ? snitch.state
    : 'MONITORING';

  const defaultSpeech = state === 'EXPECTED_LONG_RUNNING'
    ? 'The Studio server is intentionally persistent. No action needed.'
    : (state === 'SLOW_BUT_PROGRESSING'
        ? 'This task has exceeded five minutes, but progress is still detected.'
        : (state === 'STALLED' || state === 'SUSPECTED_STALL'
            ? 'No meaningful progress detected. I informed Chief.'
            : (state === 'RUNAWAY_RISK'
                ? 'A bounded process exceeded its safety contract. I raised a high-priority incident.'
                : (state === 'WAITING_FOR_HUMAN'
                    ? 'A workflow task is paused at the Human Gate awaiting sign-off.'
                    : "I'm monitoring running tasks. Everything looks healthy."))));

  const speech = typeof snitch.speech === 'string' && snitch.speech.trim()
    ? snitch.speech
    : defaultSpeech;

  const activeIncident = Boolean(snitch.incident?.active || latestAlert || incidents.length > 0);

  return {
    id: 'agent-snitch',
    name: 'SNITCH',
    role: 'OPERATIONS WATCHDOG / DELAY SENTINEL',
    state,
    speech,
    task: snitch.task || 'Active Monitoring',
    last_action: snitch.last_action || 'Monitoring operations floor for runaway tasks or stalls',
    next_action: snitch.next_action || 'Continue evidence-based monitoring',
    active_incident: activeIncident,
    incident_details: snitch.incident || latestAlert || null,
    incidents_list: incidents,
    permission_guard: resolvePermissionGuardTruth(stateData),
    auto_kill_policy: 'DISABLED (CHIEF_ESCALATION_ONLY)',
    five_minute_rule: 'RUNTIME > 5 MIN != ERROR (DISTINGUISHES PERSISTENT SERVICES AND PROGRESSING TASKS)',
  };
}

/**
 * Resolve SNITCH 3.0 Permission Guard / Sandbox Auditor truth strictly from evidence.
 */
export function resolvePermissionGuardTruth(stateData) {
  const snitch = stateData?.snitch || stateData?.agents?.['agent-snitch'] || {};
  const pg = snitch.permission_guard || stateData?.permission_guard || {};

  const status = typeof pg.status === 'string' && pg.status.trim()
    ? pg.status
    : 'PERMISSIONS HEALTHY';

  const lastCheckedCommand = typeof pg.last_checked_command === 'string' && pg.last_checked_command.trim()
    ? pg.last_checked_command
    : 'python3 scripts/launch_visual_studio.py --status';

  const ruleMatch = typeof pg.rule_match === 'string' && pg.rule_match.trim()
    ? pg.rule_match
    : 'STUDIO_LIFECYCLE';

  const recommendation = typeof pg.recommendation === 'string' && pg.recommendation.trim()
    ? pg.recommendation
    : 'ALREADY_ALLOWED';

  const riskClass = typeof pg.risk_class === 'string' && pg.risk_class.trim()
    ? pg.risk_class
    : 'SAFE';

  const speech = typeof pg.speech === 'string' && pg.speech.trim()
    ? pg.speech
    : 'All observed commands adhere to approved project rules.';

  return {
    status,
    last_checked_command: lastCheckedCommand,
    rule_match: ruleMatch,
    recommendation,
    risk_class: riskClass,
    speech,
  };
}


/**
 * Resolve Eight Bodyguards Reserve Pool truth strictly from evidence.
 */
export function resolveBodyguardsTruth(stateData) {
  const registry = [
    { slot: 'BG-01', callsign: 'ALPHA', id: 'agent-bodyguard-alpha', name: 'BODYGUARD ALPHA' },
    { slot: 'BG-02', callsign: 'BRAVO', id: 'agent-bodyguard-bravo', name: 'BODYGUARD BRAVO' },
    { slot: 'BG-03', callsign: 'CHARLIE', id: 'agent-bodyguard-charlie', name: 'BODYGUARD CHARLIE' },
    { slot: 'BG-04', callsign: 'DELTA', id: 'agent-bodyguard-delta', name: 'BODYGUARD DELTA' },
    { slot: 'BG-05', callsign: 'ECHO', id: 'agent-bodyguard-echo', name: 'BODYGUARD ECHO' },
    { slot: 'BG-06', callsign: 'FOXTROT', id: 'agent-bodyguard-foxtrot', name: 'BODYGUARD FOXTROT' },
    { slot: 'BG-07', callsign: 'GOLF', id: 'agent-bodyguard-golf', name: 'BODYGUARD GOLF' },
    { slot: 'BG-08', callsign: 'HOTEL', id: 'agent-bodyguard-hotel', name: 'BODYGUARD HOTEL' },
  ];

  const poolData = Array.isArray(stateData?.bodyguards) ? stateData.bodyguards : [];
  const agents = stateData?.agents || {};

  return registry.map(reg => {
    const fromPool = poolData.find(b => b.id === reg.id || b.callsign === reg.callsign);
    const fromAgent = agents[reg.id];
    const raw = fromPool || fromAgent || {};

    const state = typeof raw.state === 'string' && raw.state.trim()
      ? raw.state
      : 'STANDBY';

    const tempRole = typeof raw.temporary_role === 'string' && raw.temporary_role.trim()
      ? raw.temporary_role
      : null;

    const defaultSpeech = state === 'STANDBY'
      ? 'Ready for reserve duty.'
      : (state === 'ASSIGNED'
          ? `Temporary role ${tempRole || 'ACCEPTED'} received. Preparing task.`
          : (state === 'WORKING'
              ? "I'm covering this task while the specialist is busy."
              : (state === 'RETURNING'
                  ? 'Result delivered to Courier. Returning to standby.'
                  : (state === 'CAPABILITY_MISMATCH'
                      ? 'Required capability is unavailable. Flagging capability mismatch.'
                      : `Bodyguard ${reg.callsign} on reserve.`))));

    const speech = typeof raw.speech === 'string' && raw.speech.trim()
      ? raw.speech
      : defaultSpeech;

    return {
      slot: reg.slot,
      callsign: reg.callsign,
      id: reg.id,
      name: reg.name,
      state,
      temporary_role: tempRole,
      task: raw.task || (state === 'STANDBY' ? 'Reserve Duty (Standby)' : null),
      progress: Number.isFinite(raw.progress) ? raw.progress : 0.0,
      speech,
      is_standby: state === 'STANDBY',
      blocked: state === 'BLOCKED' || state === 'CAPABILITY_MISMATCH',
      model_calls_incurred: 0,
      supported_capabilities: raw.supported_capabilities || [
        'local_filesystem',
        'deterministic_execution',
        'courier_envelope_handling',
        'git_inspection',
        'media_metadata',
        'test_runner',
      ],
    };
  });
}

/**
 * Resolve Live Agent HQ Desk Matrix (37 total desks: core agents, 8 bodyguards, ~25 equipped pods, 3 future expansion).
 */
export function resolveDeskMatrix(stateData) {
  const agents = stateData?.agents || {};
  const bus = stateData?.bus || {};

  const deskDefinitions = [
    { id: 'DESK-CHIEF-01', agentId: 'agent-chief-commander', name: 'Chief Commander', zone: 'STRATEGY', icon: '👑', type: 'CORE' },
    { id: 'DESK-CURATOR-02', agentId: 'agent-thought-curator', name: 'Idea Sync / Curator', zone: 'IDEA_LAB', icon: '🧠', type: 'CORE' },
    { id: 'DESK-STEWARD-03', agentId: 'agent-update-steward', name: 'Update Steward', zone: 'CONTEXT', icon: '🔄', type: 'CORE' },
    { id: 'DESK-COURIER-04', agentId: 'agent-courier-relay', name: 'Courier Hub Relay', zone: 'COURIER', icon: '⚡', type: 'CORE' },
    { id: 'DESK-ANTIGRAVITY-05', agentId: 'agent-antigravity-bridge', name: 'Antigravity Studio', zone: 'ANTIGRAVITY', icon: '🎨', type: 'WORKER' },
    { id: 'DESK-CODEX-06', agentId: 'agent-codex-bridge', name: 'Codex Technical Lab', zone: 'CODEX', icon: '💻', type: 'WORKER' },
    { id: 'DESK-TEACHER-07', agentId: 'agent-academy-teacher', name: 'Agentenlehrer', zone: 'ACADEMY', icon: '👨‍🏫', type: 'ACADEMY' },
    { id: 'DESK-DIRECTOR-08', agentId: 'agent-academy-director', name: 'Schuldirektor', zone: 'ACADEMY', icon: '🏛️', type: 'ACADEMY' },
    { id: 'DESK-ROUTER-09', agentId: 'smart-resource-router', name: 'Smart Router', zone: 'STRATEGY', icon: '🧭', type: 'ROUTER' },
    { id: 'DESK-SNITCH-10', agentId: 'agent-snitch', name: 'SNITCH Watchdog', zone: 'SERVER', icon: '👀', type: 'WATCHDOG' },
    { id: 'DESK-ASSET-11', agentId: 'agent-asset-validator', name: 'Asset Validator', zone: 'ANTIGRAVITY', icon: '📐', type: 'WORKER' },
    { id: 'DESK-VIDEO-12', agentId: 'agent-video-synth', name: 'Video Synth', zone: 'ANTIGRAVITY', icon: '🎬', type: 'WORKER' },
    { id: 'DESK-CHANNEL-13', agentId: 'agent-channel-dispatcher', name: 'Channel Dispatcher', zone: 'COURIER', icon: '📡', type: 'COURIER' },
    { id: 'DESK-MEMORY-14', agentId: 'agent-memory-mesh', name: 'Memory Mesh Indexer', zone: 'IDEA_LAB', icon: '🗄️', type: 'INDEXER' },
    { id: 'DESK-GATE-15', agentId: 'agent-human-gate-monitor', name: 'Human Gate Monitor', zone: 'STRATEGY', icon: '🚨', type: 'GATE' },
    { id: 'DESK-TEST-16', agentId: 'agent-test-guardian', name: 'Test Guardian', zone: 'CODEX', icon: '🧪', type: 'QA' },
    { id: 'DESK-LOOP-17', agentId: 'agent-loop-supervisor', name: 'Loop Supervisor', zone: 'STRATEGY', icon: '🔁', type: 'SUPERVISOR' },
    { id: 'DESK-BG-01', agentId: 'agent-bodyguard-alpha', name: 'Bodyguard Alpha', zone: 'BODYGUARDS', icon: '🛡️', type: 'BODYGUARD' },
    { id: 'DESK-BG-02', agentId: 'agent-bodyguard-bravo', name: 'Bodyguard Bravo', zone: 'BODYGUARDS', icon: '🛡️', type: 'BODYGUARD' },
    { id: 'DESK-BG-03', agentId: 'agent-bodyguard-charlie', name: 'Bodyguard Charlie', zone: 'BODYGUARDS', icon: '🛡️', type: 'BODYGUARD' },
    { id: 'DESK-BG-04', agentId: 'agent-bodyguard-delta', name: 'Bodyguard Delta', zone: 'BODYGUARDS', icon: '🛡️', type: 'BODYGUARD' },
    { id: 'DESK-BG-05', agentId: 'agent-bodyguard-echo', name: 'Bodyguard Echo', zone: 'BODYGUARDS', icon: '🛡️', type: 'BODYGUARD' },
    { id: 'DESK-BG-06', agentId: 'agent-bodyguard-foxtrot', name: 'Bodyguard Foxtrot', zone: 'BODYGUARDS', icon: '🛡️', type: 'BODYGUARD' },
    { id: 'DESK-BG-07', agentId: 'agent-bodyguard-golf', name: 'Bodyguard Golf', zone: 'BODYGUARDS', icon: '🛡️', type: 'BODYGUARD' },
    { id: 'DESK-BG-08', agentId: 'agent-bodyguard-hotel', name: 'Bodyguard Hotel', zone: 'BODYGUARDS', icon: '🛡️', type: 'BODYGUARD' },
    { id: 'DESK-EQUIPPED-18', agentId: null, name: 'Code Review Pod', zone: 'CODEX', icon: '📝', type: 'EQUIPPED' },
    { id: 'DESK-EQUIPPED-19', agentId: null, name: '3D Shader Workbench', zone: 'ANTIGRAVITY', icon: '✨', type: 'EQUIPPED' },
    { id: 'DESK-EQUIPPED-20', agentId: null, name: 'Audio Synth Station', zone: 'ANTIGRAVITY', icon: '🎙️', type: 'EQUIPPED' },
    { id: 'DESK-EQUIPPED-21', agentId: null, name: 'Memory Diff Inspector', zone: 'IDEA_LAB', icon: '📑', type: 'EQUIPPED' },
    { id: 'DESK-EQUIPPED-22', agentId: null, name: 'Academy Eval Pod', zone: 'ACADEMY', icon: '📊', type: 'EQUIPPED' },
    { id: 'DESK-EQUIPPED-23', agentId: null, name: 'Opportunity Scout Desk', zone: 'ACADEMY', icon: '🔭', type: 'EQUIPPED' },
    { id: 'DESK-EQUIPPED-24', agentId: null, name: 'Economics Tracker', zone: 'STRATEGY', icon: '📈', type: 'EQUIPPED' },
    { id: 'DESK-EQUIPPED-25', agentId: null, name: 'Incident Responder Pod', zone: 'SERVER', icon: '🚒', type: 'EQUIPPED' },
    { id: 'DESK-FUTURE-26', agentId: null, name: 'Expansion Station Alpha', zone: 'FUTURE', icon: '🔮', type: 'FUTURE' },
    { id: 'DESK-FUTURE-27', agentId: null, name: 'Expansion Station Beta', zone: 'FUTURE', icon: '🔮', type: 'FUTURE' },
    { id: 'DESK-FUTURE-28', agentId: null, name: 'Expansion Station Gamma', zone: 'FUTURE', icon: '🔮', type: 'FUTURE' },
  ];

  return deskDefinitions.map(def => {
    if (def.type === 'FUTURE') {
      return { ...def, status: 'FUTURE_EXPANSION', state: 'FUTURE', task: null, execution_class: 'UNKNOWN' };
    }

    if (!def.agentId) {
      return { ...def, status: 'REGISTERED_EQUIPPED', state: 'REGISTERED', task: null, execution_class: 'REGISTERED' };
    }

    const agent = agents[def.agentId];
    if (!agent) {
      // Check if it's a bodyguard in pool
      if (def.type === 'BODYGUARD') {
        const bgs = resolveBodyguardsTruth(stateData);
        const bg = bgs.find(b => b.id === def.agentId);
        if (bg) {
          const bgState = bg.state;
          const isBgBusy = bgState === 'WORKING' || bgState === 'PREPARING' || bgState === 'ASSIGNED';
          const isBgBlocked = bgState === 'BLOCKED' || bgState === 'CAPABILITY_MISMATCH';
          return {
            ...def,
            status: isBgBlocked ? 'BLOCKED' : (isBgBusy ? 'ACTIVE' : 'IDLE'),
            state: bgState,
            task: bg.task || 'Reserve Duty (Standby)',
            execution_class: 'DETERMINISTIC_ANTIGRAVITY',
            progress: bg.progress,
            temporary_role: bg.temporary_role,
            speech: bg.speech,
          };
        }
      }
      return { ...def, status: 'UNKNOWN', state: 'UNKNOWN', task: null, execution_class: 'UNKNOWN' };
    }

    const state = typeof agent.state === 'string' ? agent.state : 'IDLE';
    const isBusy = state === 'RUNNING' || state === 'COMPARING' || state === 'REVIEWING' || state === 'COORDINATING' || state === 'WORKING';
    const isBlocked = agent.blocked || bus.human_gate || state.includes('BLOCKED') || state === 'CAPABILITY_MISMATCH';

    return {
      ...def,
      status: isBlocked ? 'BLOCKED' : (isBusy ? 'ACTIVE' : 'IDLE'),
      state,
      task: agent.task || 'Standby',
      execution_class: resolveExecutionTruth(agent),
      progress: Number.isFinite(agent.progress) ? agent.progress : 0.0,
      speech: agent.speech || null,
      temporary_role: agent.temporary_role || null,
    };
  });
}

/**
 * Resolve Live HQ Master Overview metrics for the Large Dashboard / TV Wall.
 */
export function resolveLiveHQMetrics(stateData) {
  const desks = resolveDeskMatrix(stateData);
  const bus = stateData?.bus || {};
  const snapshot = stateData?.context_snapshot;
  const hasMachineState = Object.keys(stateData?.agents || {}).length > 0 || Boolean(stateData?.bus);

  let activeCount = 0;
  let idleCount = 0;
  let blockedCount = 0;
  let availableCount = 0;
  let futureCount = 0;

  for (const desk of desks) {
    if (desk.status === 'ACTIVE') activeCount++;
    else if (desk.status === 'BLOCKED') blockedCount++;
    else if (desk.status === 'IDLE') idleCount++;
    else if (desk.status === 'REGISTERED_EQUIPPED') availableCount++;
    else if (desk.status === 'FUTURE_EXPANSION') futureCount++;
  }

  return {
    total_desks: desks.length,
    active_agents: activeCount,
    idle_agents: idleCount,
    blocked_agents: blockedCount,
    available_workstations: availableCount,
    future_workstations: futureCount,
    total_capacity: 40,
    chief_wait_state: resolveChiefWaitState(stateData),
    current_workflow: typeof bus.active_workflow === 'string' && bus.active_workflow !== 'IDLE_MONITORING'
      ? bus.active_workflow
      : null,
    correlation_id: resolveCorrelationTruth(bus),
    context_version: Number.isFinite(snapshot?.context_version)
      ? snapshot.context_version
      : (Number.isFinite(bus.context_version) && bus.context_version > 0 ? bus.context_version : null),
    system_health: !hasMachineState
      ? 'UNKNOWN'
      : (blockedCount > 0 ? 'ATTENTION_REQUIRED' : (bus.is_locked ? 'OPERATIONAL_BUSY' : 'OPERATIONAL_HEALTHY')),
  };
}


// This is a static explanation of the architecture, not execution evidence.
export const ACADEMY_FLOW_STEPS = Object.freeze([
  'EXTERNAL FINDING',
  'AGENTENLEHRER',
  'LESSON',
  'SCHULDIREKTOR',
  'TEST / EVAL',
  'IDEA SYNC',
  'CHIEF',
  'UPDATE STEWARD',
  'NEW CONTEXT VERSION',
  'AFFECTED AGENT',
]);

/**
 * Resolve Living Room Character Positions, Nameplates, Speech, and Visual States.
 */
export function resolveLivingRoomAgents(stateData) {
  const agents = stateData?.agents || {};
  const bus = stateData?.bus || {};
  const desks = resolveDeskMatrix(stateData);
  const bodyguards = resolveBodyguardsTruth(stateData);

  // Default coordinate map matching the 16:9 pixel-art reference image
  const baseCoordinates = {
    'agent-chief-commander': { x: 50.0, y: 42.0, zone: 'COMMAND_TABLE', name: 'CHIEF COMMANDER', title: 'Chief / Strategy' },
    'smart-resource-router': { x: 57.5, y: 44.0, zone: 'COMMAND_TABLE', name: 'SMART ROUTER', title: 'Task Router' },
    'agent-human-gate-monitor': { x: 14.5, y: 35.5, zone: 'DESK_01', name: 'HUMAN GATE', title: 'Human Gate / Strategy' },
    'agent-thought-curator': { x: 22.0, y: 35.5, zone: 'DESK_02', name: 'IDEA SYNC', title: 'Memory & Curation' },
    'agent-update-steward': { x: 29.5, y: 35.5, zone: 'DESK_03', name: 'UPDATE STEWARD', title: 'Context Sync Steward' },
    'agent-codex-bridge': { x: 14.5, y: 48.0, zone: 'DESK_04', name: 'CODEX', title: 'Technical QA Specialist' },
    'agent-asset-validator': { x: 22.0, y: 48.0, zone: 'DESK_05', name: 'ASSET VALIDATOR', title: 'Media Asset Validator' },
    'agent-video-synth': { x: 29.5, y: 48.0, zone: 'DESK_06', name: 'VIDEO SYNTH', title: '3D Movie Synth' },
    'agent-channel-dispatcher': { x: 14.5, y: 60.5, zone: 'DESK_07', name: 'CHANNEL DISPATCH', title: 'Social Dispatcher' },
    'agent-memory-mesh': { x: 22.0, y: 60.5, zone: 'DESK_08', name: 'MEMORY MESH', title: 'Project Memory Indexer' },
    'agent-test-guardian': { x: 29.5, y: 60.5, zone: 'DESK_09', name: 'TEST GUARDIAN', title: 'Regression Sentinel' },
    'agent-antigravity-bridge': { x: 66.5, y: 45.0, zone: 'DESK_16', name: 'ANTIGRAVITY', title: 'Visual & Heavy Worker' },
    'agent-courier-relay': { x: 74.0, y: 45.0, zone: 'DESK_17', name: 'COURIER', title: 'Message Transport' },
    'agent-academy-teacher': { x: 81.5, y: 45.0, zone: 'DESK_19', name: 'ACADEMY TEACHER', title: 'Agentenlehrer' },
    'agent-academy-director': { x: 89.0, y: 45.0, zone: 'DESK_21', name: 'ACADEMY DIRECTOR', title: 'Schuldirektor' },
    'agent-snitch': { x: 63.5, y: 59.5, zone: 'DESK_13', name: 'SNITCH 3.0', title: 'Runtime & Permission Guard' },
    'agent-loop-supervisor': { x: 71.0, y: 59.5, zone: 'DESK_22', name: 'LOOP SUPERVISOR', title: 'L6 Orchestration' },
  };

  // Bodyguard leisure vs active positions
  const bodyguardStandbySlots = [
    { callsign: 'ALPHA', leisure_area: 'SAUNA', x: 79.0, y: 14.0 },
    { callsign: 'BRAVO', leisure_area: 'SAUNA', x: 84.0, y: 14.0 },
    { callsign: 'CHARLIE', leisure_area: 'COFFEE_BAR', x: 80.0, y: 91.0 },
    { callsign: 'DELTA', leisure_area: 'COFFEE_BAR', x: 85.0, y: 91.0 },
    { callsign: 'ECHO', leisure_area: 'VISITOR_LOUNGE', x: 12.0, y: 84.0 },
    { callsign: 'FOXTROT', leisure_area: 'VISITOR_LOUNGE', x: 28.0, y: 84.0 },
    { callsign: 'GOLF', leisure_area: 'READY_ROOM', x: 44.0, y: 67.0 },
    { callsign: 'HOTEL', leisure_area: 'READY_ROOM', x: 56.0, y: 67.0 },
  ];

  const assignedWorkstationCoords = [
    { x: 78.5, y: 59.5 }, // Desk 23
    { x: 86.0, y: 59.5 }, // Desk 24
    { x: 80.0, y: 73.5 }, // Desk 24 lower
    { x: 88.0, y: 73.5 }, // Desk 25 lower
  ];

  const results = [];

  // 1. Process Core & Specialist Agents
  for (const [agentId, coords] of Object.entries(baseCoordinates)) {
    const raw = agents[agentId] || {};
    const desk = desks.find(d => d.agentId === agentId) || {};
    const state = typeof raw.state === 'string' && raw.state.trim() ? raw.state : (desk.state || 'IDLE');
    const task = raw.task || desk.task || (state === 'IDLE' ? 'Standby' : state);
    const progress = Number.isFinite(raw.progress) ? raw.progress : (desk.progress || 0.0);
    const speech = raw.speech || resolveSpeechBubble(agentId, { state, task, ...raw }, bus);

    const isBusy = state === 'RUNNING' || state === 'COMPARING' || state === 'REVIEWING' || state === 'COORDINATING' || state === 'WORKING';
    const isBlocked = raw.blocked || desk.status === 'BLOCKED';

    results.push({
      id: agentId,
      name: coords.name,
      title: coords.title,
      zone: coords.zone,
      x: coords.x,
      y: coords.y,
      homeX: coords.x,
      homeY: coords.y,
      state,
      task,
      progress,
      speech,
      is_active: isBusy,
      is_blocked: isBlocked,
      is_bodyguard: false,
      role: raw.role || coords.title,
      animation: isBusy ? 'working' : (isBlocked ? 'blocked' : 'idle'),
    });
  }

  // 2. Process Eight Reserve Bodyguards
  bodyguards.forEach((bg, idx) => {
    const slot = bodyguardStandbySlots[idx] || { callsign: bg.callsign, x: 14 + idx * 4.5, y: 63.5, leisure_area: 'READY_ROOM' };
    const isAssigned = bg.state === 'ASSIGNED' || bg.state === 'WORKING' || bg.state === 'RETURNING';
    
    let targetX = slot.x;
    let targetY = slot.y;

    if (isAssigned) {
      const assignedDesk = assignedWorkstationCoords[idx % assignedWorkstationCoords.length];
      targetX = assignedDesk.x;
      targetY = assignedDesk.y;
    }

    let speechText = bg.speech;
    if (!speechText || speechText.includes('on reserve') || speechText.includes('Ready for reserve duty')) {
      if (bg.state === 'STANDBY') {
        if (slot.leisure_area === 'COFFEE_BAR') speechText = `Standing by at the coffee bar.`;
        else if (slot.leisure_area === 'SAUNA') speechText = `Standing by in the sauna.`;
        else if (slot.leisure_area === 'VISITOR_LOUNGE') speechText = `Standing by in the visitor lounge.`;
        else speechText = `Standing by in the ready room.`;
      } else if (bg.state === 'WORKING') {
        speechText = `Covering ${bg.temporary_role || 'task'} at workstation.`;
      } else if (bg.state === 'RETURNING') {
        speechText = `Task complete. Returning to standby.`;
      }
    }

    results.push({
      id: bg.id,
      name: `BODYGUARD ${bg.callsign}`,
      title: bg.temporary_role ? `TEMP: ${bg.temporary_role}` : `RESERVE ${bg.slot}`,
      zone: 'BODYGUARDS',
      x: targetX,
      y: targetY,
      homeX: slot.x,
      homeY: slot.y,
      state: bg.state,
      task: bg.task || (bg.state === 'STANDBY' ? 'Reserve Duty (Standby)' : bg.state),
      progress: bg.progress,
      speech: speechText,
      is_active: isAssigned,
      is_blocked: bg.blocked,
      is_bodyguard: true,
      callsign: bg.callsign,
      slot: bg.slot,
      leisure_area: slot.leisure_area,
      animation: bg.state === 'WORKING' ? 'working' : (bg.state === 'RETURNING' ? 'walking' : 'idle'),
    });
  });

  return results;
}

// --------------------------------------------------------------------------
// 11. WALKABLE NAVIGATION GRAPH & WAYPOINT PATHFINDER
// --------------------------------------------------------------------------

export const HQ_WAYPOINTS = Object.freeze({
  // Corridors & Crossroads
  'CORRIDOR_NORTH': { x: 50.0, y: 35.0 },
  'CORRIDOR_COMMAND': { x: 50.0, y: 48.0 },
  'CORRIDOR_CROSS_MID': { x: 50.0, y: 56.0 },
  'CORRIDOR_FOUNTAIN_TOP': { x: 50.0, y: 60.0 },
  'CORRIDOR_FOUNTAIN_LEFT': { x: 38.0, y: 67.0 },
  'CORRIDOR_FOUNTAIN_RIGHT': { x: 62.0, y: 67.0 },
  'CORRIDOR_SOUTH': { x: 50.0, y: 80.0 },
  'CORRIDOR_BOTTOM_CROSS': { x: 50.0, y: 90.0 },
  'LEFT_AISLE_TOP': { x: 34.0, y: 35.5 },
  'LEFT_AISLE_MID': { x: 34.0, y: 48.0 },
  'LEFT_AISLE_BOT': { x: 34.0, y: 60.5 },
  'RIGHT_AISLE_TOP': { x: 62.0, y: 45.0 },
  'RIGHT_AISLE_MID': { x: 62.0, y: 59.5 },
  'RIGHT_AISLE_BOT': { x: 62.0, y: 73.5 },

  // Key Workstations & Zones
  'CHIEF_COMMAND': { x: 50.0, y: 42.0 },
  'ROUTER_DESK': { x: 57.5, y: 44.0 },
  'DESK_01': { x: 14.5, y: 35.5 },
  'DESK_02': { x: 22.0, y: 35.5 },
  'DESK_03': { x: 29.5, y: 35.5 },
  'DESK_04': { x: 14.5, y: 48.0 },
  'DESK_05': { x: 22.0, y: 48.0 },
  'DESK_06': { x: 29.5, y: 48.0 },
  'DESK_07': { x: 14.5, y: 60.5 },
  'DESK_08': { x: 22.0, y: 60.5 },
  'DESK_09': { x: 29.5, y: 60.5 },
  'DESK_16': { x: 66.5, y: 45.0 },
  'DESK_17': { x: 74.0, y: 45.0 },
  'DESK_19': { x: 81.5, y: 45.0 },
  'DESK_21': { x: 89.0, y: 45.0 },
  'DESK_13': { x: 63.5, y: 59.5 },
  'DESK_22': { x: 71.0, y: 59.5 },
  'DESK_23': { x: 78.5, y: 59.5 },
  'DESK_24': { x: 86.0, y: 59.5 },
  'DESK_24_LOW': { x: 80.0, y: 73.5 },
  'DESK_25_LOW': { x: 88.0, y: 73.5 },

  // Special Facilities
  'SAUNA_ALPHA': { x: 79.0, y: 14.0 },
  'SAUNA_BRAVO': { x: 84.0, y: 14.0 },
  'COFFEE_BAR_CHARLIE': { x: 80.0, y: 91.0 },
  'COFFEE_BAR_DELTA': { x: 85.0, y: 91.0 },
  'VISITOR_LOUNGE_ECHO': { x: 12.0, y: 84.0 },
  'VISITOR_LOUNGE_FOXTROT': { x: 28.0, y: 84.0 },
  'READY_ROOM_GOLF': { x: 44.0, y: 67.0 },
  'READY_ROOM_HOTEL': { x: 56.0, y: 67.0 },
  'SERVER_ROOM': { x: 88.0, y: 38.0 },
  'FIREPLACE': { x: 18.0, y: 28.0 },
});

export const HQ_NAV_GRAPH = Object.freeze({
  'CHIEF_COMMAND': ['CORRIDOR_COMMAND', 'ROUTER_DESK'],
  'ROUTER_DESK': ['CHIEF_COMMAND', 'RIGHT_AISLE_TOP'],
  'CORRIDOR_NORTH': ['CORRIDOR_COMMAND', 'LEFT_AISLE_TOP', 'SAUNA_ALPHA', 'FIREPLACE'],
  'CORRIDOR_COMMAND': ['CHIEF_COMMAND', 'CORRIDOR_NORTH', 'CORRIDOR_CROSS_MID'],
  'CORRIDOR_CROSS_MID': ['CORRIDOR_COMMAND', 'CORRIDOR_FOUNTAIN_TOP', 'LEFT_AISLE_MID', 'RIGHT_AISLE_MID'],
  'CORRIDOR_FOUNTAIN_TOP': ['CORRIDOR_CROSS_MID', 'CORRIDOR_FOUNTAIN_LEFT', 'CORRIDOR_FOUNTAIN_RIGHT'],
  'CORRIDOR_FOUNTAIN_LEFT': ['CORRIDOR_FOUNTAIN_TOP', 'CORRIDOR_SOUTH', 'READY_ROOM_GOLF', 'LEFT_AISLE_BOT'],
  'CORRIDOR_FOUNTAIN_RIGHT': ['CORRIDOR_FOUNTAIN_TOP', 'CORRIDOR_SOUTH', 'READY_ROOM_HOTEL', 'RIGHT_AISLE_MID'],
  'CORRIDOR_SOUTH': ['CORRIDOR_FOUNTAIN_LEFT', 'CORRIDOR_FOUNTAIN_RIGHT', 'CORRIDOR_BOTTOM_CROSS', 'RIGHT_AISLE_BOT'],
  'CORRIDOR_BOTTOM_CROSS': ['CORRIDOR_SOUTH', 'VISITOR_LOUNGE_FOXTROT', 'COFFEE_BAR_CHARLIE'],

  'LEFT_AISLE_TOP': ['CORRIDOR_NORTH', 'DESK_01', 'DESK_02', 'DESK_03', 'LEFT_AISLE_MID'],
  'LEFT_AISLE_MID': ['LEFT_AISLE_TOP', 'CORRIDOR_CROSS_MID', 'DESK_04', 'DESK_05', 'DESK_06', 'LEFT_AISLE_BOT'],
  'LEFT_AISLE_BOT': ['LEFT_AISLE_MID', 'CORRIDOR_FOUNTAIN_LEFT', 'DESK_07', 'DESK_08', 'DESK_09', 'VISITOR_LOUNGE_ECHO'],

  'RIGHT_AISLE_TOP': ['ROUTER_DESK', 'DESK_16', 'DESK_17', 'DESK_19', 'DESK_21', 'SERVER_ROOM', 'RIGHT_AISLE_MID'],
  'RIGHT_AISLE_MID': ['RIGHT_AISLE_TOP', 'CORRIDOR_CROSS_MID', 'CORRIDOR_FOUNTAIN_RIGHT', 'DESK_13', 'DESK_22', 'DESK_23', 'DESK_24', 'RIGHT_AISLE_BOT'],
  'RIGHT_AISLE_BOT': ['RIGHT_AISLE_MID', 'CORRIDOR_SOUTH', 'DESK_24_LOW', 'DESK_25_LOW', 'COFFEE_BAR_CHARLIE'],

  'DESK_01': ['LEFT_AISLE_TOP'],
  'DESK_02': ['LEFT_AISLE_TOP'],
  'DESK_03': ['LEFT_AISLE_TOP'],
  'DESK_04': ['LEFT_AISLE_MID'],
  'DESK_05': ['LEFT_AISLE_MID'],
  'DESK_06': ['LEFT_AISLE_MID'],
  'DESK_07': ['LEFT_AISLE_BOT'],
  'DESK_08': ['LEFT_AISLE_BOT'],
  'DESK_09': ['LEFT_AISLE_BOT'],

  'DESK_16': ['RIGHT_AISLE_TOP'],
  'DESK_17': ['RIGHT_AISLE_TOP'],
  'DESK_19': ['RIGHT_AISLE_TOP'],
  'DESK_21': ['RIGHT_AISLE_TOP'],
  'DESK_13': ['RIGHT_AISLE_MID'],
  'DESK_22': ['RIGHT_AISLE_MID'],
  'DESK_23': ['RIGHT_AISLE_MID'],
  'DESK_24': ['RIGHT_AISLE_MID'],
  'DESK_24_LOW': ['RIGHT_AISLE_BOT'],
  'DESK_25_LOW': ['RIGHT_AISLE_BOT'],

  'SAUNA_ALPHA': ['CORRIDOR_NORTH', 'SAUNA_BRAVO'],
  'SAUNA_BRAVO': ['SAUNA_ALPHA'],
  'COFFEE_BAR_CHARLIE': ['CORRIDOR_BOTTOM_CROSS', 'RIGHT_AISLE_BOT', 'COFFEE_BAR_DELTA'],
  'COFFEE_BAR_DELTA': ['COFFEE_BAR_CHARLIE'],
  'VISITOR_LOUNGE_ECHO': ['LEFT_AISLE_BOT', 'VISITOR_LOUNGE_FOXTROT'],
  'VISITOR_LOUNGE_FOXTROT': ['CORRIDOR_BOTTOM_CROSS', 'VISITOR_LOUNGE_ECHO'],
  'READY_ROOM_GOLF': ['CORRIDOR_FOUNTAIN_LEFT', 'READY_ROOM_HOTEL'],
  'READY_ROOM_HOTEL': ['CORRIDOR_FOUNTAIN_RIGHT', 'READY_ROOM_GOLF'],
  'SERVER_ROOM': ['RIGHT_AISLE_TOP'],
  'FIREPLACE': ['CORRIDOR_NORTH'],
});

export function findNearestWaypoint(x, y) {
  let bestKey = 'CORRIDOR_CROSS_MID';
  let bestDist = Infinity;
  for (const [key, pt] of Object.entries(HQ_WAYPOINTS)) {
    const dist = Math.hypot(pt.x - x, pt.y - y);
    if (dist < bestDist) {
      bestDist = dist;
      bestKey = key;
    }
  }
  return bestKey;
}

export function bfsNavGraph(startWp, targetWp) {
  if (startWp === targetWp) return [startWp];
  const queue = [[startWp]];
  const visited = new Set([startWp]);

  while (queue.length > 0) {
    const path = queue.shift();
    const node = path[path.length - 1];
    const neighbors = HQ_NAV_GRAPH[node] || [];

    for (const neighbor of neighbors) {
      if (neighbor === targetWp) {
        return [...path, neighbor];
      }
      if (!visited.has(neighbor)) {
        visited.add(neighbor);
        queue.push([...path, neighbor]);
      }
    }
  }
  return [startWp, targetWp];
}

export function findWalkingPath(startX, startY, targetX, targetY) {
  const dist = Math.hypot(targetX - startX, targetY - startY);
  if (dist < 1.5) return [{ x: targetX, y: targetY }];

  const startWp = findNearestWaypoint(startX, startY);
  const targetWp = findNearestWaypoint(targetX, targetY);

  if (startWp === targetWp) {
    return [HQ_WAYPOINTS[startWp], { x: targetX, y: targetY }];
  }

  const pathKeys = bfsNavGraph(startWp, targetWp);
  const coordsPath = pathKeys.map(k => ({ ...HQ_WAYPOINTS[k] }));
  coordsPath.push({ x: targetX, y: targetY });
  return coordsPath;
}


