#!/usr/bin/env python3
"""Autonomous Chief Operations Cockpit Server for 2026 Courier.

Serves the Studio Web UI and provides real-time state aggregation over the Courier Event Bus:
- /api/state: Aggregates Chief, Antigravity, and Codex visual states, queues, and locks.
- /api/submit-idea: Ingests human ideas/goals and routes them through the Chief Commander.
- /api/human-gate: Persists explicit human approval or rejection events to resume/stop workflows.
- /api/trigger-workflow: Triggers a demonstration multi-round autonomous loop.
"""

from __future__ import annotations

import argparse
import datetime
import http.server
import json
import os
import socketserver
import sys
import threading
import time
import uuid
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent
COURIER_DIR = SCRIPTS_DIR.parent
STUDIO_DIR = COURIER_DIR / "studio"
EVENTS_DIR = COURIER_DIR / "events"

APPROVALS_DIR = EVENTS_DIR / "approvals"
APPROVALS_DIR.mkdir(parents=True, exist_ok=True)

# Add scripts directory to path for imports
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

try:
    from run_chief_commander import ChiefCommander
    from run_bodyguards import BodyguardPoolManager
except ImportError:
    from scripts.run_chief_commander import ChiefCommander
    from scripts.run_bodyguards import BodyguardPoolManager



def load_json_safe(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_json_safe(path: Path, data: dict) -> None:
    try:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
        tmp.replace(path)
    except Exception as e:
        print(f"[SERVER] Error saving {path}: {e}")


def _nonempty_text(value: object) -> str | None:
    return value.strip() if isinstance(value, str) and value.strip() else None


def load_agent_states(states_dir: Path) -> dict[str, dict]:
    """Load machine state without creating an inferred human-gate identity."""
    states: dict[str, dict] = {}
    if not states_dir.exists():
        return states
    for state_file in states_dir.glob("*.json"):
        data = load_json_safe(state_file)
        agent_id = _nonempty_text(data.get("id"))
        if agent_id:
            states[agent_id] = data
    return states


def find_active_human_gate(agents_data: dict[str, dict]) -> dict | None:
    """Return the active gate and only its recorded provenance.

    A legacy gate without workflow/correlation remains visible, but cannot be
    approved or associated with a decision until it has complete provenance.
    """
    for agent_id in sorted(agents_data):
        agent = agents_data[agent_id]
        if agent.get("human_gate") or agent.get("state") in {
            "BLOCKED_HUMAN_GATE", "BLOCKED_POLICY_CONFLICT", "CONFLICT"
        }:
            workflow_id = _nonempty_text(agent.get("workflow"))
            correlation_id = _nonempty_text(agent.get("correlation_id"))
            return {
                "agent_id": agent_id,
                "workflow_id": workflow_id,
                "correlation_id": correlation_id,
                "task_id": _nonempty_text(agent.get("task")),
                "state": _nonempty_text(agent.get("state")) or "UNKNOWN",
                "provenance_complete": bool(workflow_id and correlation_id),
            }
    return None


def resolve_active_gate_decision(gate: dict | None, decisions_dir: Path, approvals_dir: Path) -> dict:
    """Resolve only a decision whose complete provenance matches the gate."""
    result = {
        "status": "NO_DECISION",
        "workflow_id": gate.get("workflow_id") if gate else None,
        "correlation_id": gate.get("correlation_id") if gate else None,
        "source": None,
        "provenance_complete": bool(gate and gate.get("provenance_complete")),
    }
    if not gate or not gate.get("provenance_complete"):
        return result

    candidates: list[tuple[float, str, str]] = []
    for directory, source, field in (
        (decisions_dir, "CHIEF_DECISION", "verdict"),
        (approvals_dir, "HUMAN_APPROVAL", "action"),
    ):
        if not directory.exists():
            continue
        for path in directory.glob("*.json"):
            data = load_json_safe(path)
            if (
                data.get("workflow_id") == gate["workflow_id"]
                and data.get("correlation_id") == gate["correlation_id"]
            ):
                value = _nonempty_text(data.get(field))
                if value:
                    candidates.append((path.stat().st_mtime, source, value))
    if candidates:
        _, source, status = max(candidates, key=lambda item: item[0])
        result.update({"status": status, "source": source})
    return result


class StudioHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STUDIO_DIR), **kwargs)

    def do_GET(self):
        if self.path == "/api/state":
            self.handle_api_state()
        elif self.path == "/" or self.path == "/index.html":
            super().do_GET()
        else:
            super().do_GET()

    def do_POST(self):
        if self.path == "/api/submit-idea":
            self.handle_submit_idea()
        elif self.path == "/api/human-gate":
            self.handle_human_gate()
        elif self.path == "/api/trigger-workflow":
            self.handle_trigger_workflow()
        elif self.path == "/api/trigger-demo":
            self.handle_trigger_demo()
        else:
            self.send_error(404, "Endpoint not found")

    def handle_api_state(self):
        states_dir = EVENTS_DIR / "agent-states"
        agents_data = load_agent_states(states_dir)
        for data in agents_data.values():
            # Ground execution_class strictly in evidence.
            if "execution_class" not in data:
                data["execution_class"] = data.get("result_execution_class", "UNKNOWN")

        dispatch_dir = EVENTS_DIR / "dispatch"
        processed_dir = EVENTS_DIR / "processed"
        decisions_dir = EVENTS_DIR / "chief-decisions"
        locks_dir = EVENTS_DIR / "locks"
        approvals_dir = EVENTS_DIR / "approvals"
        runtime_alerts_dir = EVENTS_DIR / "runtime-alerts"

        counts = {
            "dispatch": len(list(dispatch_dir.glob("*.json"))) if dispatch_dir.exists() else 0,
            "processed": len(list(processed_dir.glob("*.json"))) if processed_dir.exists() else 0,
            "decisions": len(list(decisions_dir.glob("*.json"))) if decisions_dir.exists() else 0,
            "approvals": len(list(approvals_dir.glob("*.json"))) if approvals_dir.exists() else 0,
            "runtime_alerts": len(list(runtime_alerts_dir.glob("*.json"))) if runtime_alerts_dir.exists() else 0,
        }

        active_locks = list(locks_dir.glob("*.lock")) if locks_dir.exists() else []
        is_locked = len(active_locks) > 0
        active_lock_name = active_locks[0].stem if is_locked else None

        # Derive Last Decision Truth
        last_decision = "NO_DECISION"
        if decisions_dir.exists():
            dec_files = sorted(decisions_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            if dec_files:
                last_dec_data = load_json_safe(dec_files[0])
                last_decision = last_dec_data.get("verdict", "NO_DECISION")

        # Derive Correlation ID Truth (No Synthetic Random Generation, No Workflow Name Derivations)
        derived_correlation_id = "UNKNOWN"
        if is_locked and active_lock_name:
            lock_data = load_json_safe(active_locks[0])
            derived_correlation_id = lock_data.get("correlation_id", "UNKNOWN")
        else:
            recent_files = []
            if dispatch_dir.exists():
                recent_files.extend(dispatch_dir.glob("*.json"))
            if processed_dir.exists():
                recent_files.extend(processed_dir.glob("*.json"))
            if recent_files:
                sorted_events = sorted(recent_files, key=lambda p: p.stat().st_mtime, reverse=True)
                latest_evt = load_json_safe(sorted_events[0])
                derived_correlation_id = latest_evt.get("correlation_id", "UNKNOWN")

        # A gate is active based on machine state.  Its decision may only be
        # attached when both workflow_id and correlation_id match exactly.
        active_human_gate = find_active_human_gate(agents_data)
        human_gate_active = active_human_gate is not None
        gate_decision = resolve_active_gate_decision(
            active_human_gate, decisions_dir, approvals_dir
        )

        latest_runtime_alert = None
        if runtime_alerts_dir.exists():
            alert_files = sorted(runtime_alerts_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            if alert_files:
                latest_runtime_alert = load_json_safe(alert_files[0]) or None

        treasury = {
            "eur": None,
            "usd": None,
            "last_verified_at": None,
            "goal_current_usd": 8,
            "goal_target_usd": 1_000_000_000,
            "goal_status": "ASPIRATIONAL_MANUAL_NOT_VERIFIED",
        }

        # Read latest context snapshot
        snapshot_file = EVENTS_DIR / "context-snapshots/snapshot-current.json"
        snapshot_data = load_json_safe(snapshot_file) if snapshot_file.exists() else None

        # Read academy structured evidence
        academy_dir = EVENTS_DIR / "academy"
        academy_data = None
        if academy_dir.exists():
            config_data = load_json_safe(academy_dir / "config.json")
            econ_data = load_json_safe(academy_dir / "economics.json")

            # Collect latest lessons (bounded to latest 15)
            lessons_dir = academy_dir / "lessons"
            recent_lessons = []
            opportunity_candidates = []
            if lessons_dir.exists():
                lfiles = sorted(lessons_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
                for lf in lfiles[:15]:
                    ld = load_json_safe(lf)
                    if ld and "lesson_id" in ld:
                        summary_entry = {
                            "lesson_id": ld.get("lesson_id"),
                            "title": ld.get("title"),
                            "topic": ld.get("topic"),
                            "status": ld.get("status", "DISCOVERED"),
                            "lesson_type": ld.get("lesson_type"),
                            "risk": ld.get("risk", "LOW"),
                            "affected_agents": ld.get("affected_agents", []),
                            "expected_benefit": ld.get("expected_benefit"),
                            "discovered_at": ld.get("discovered_at"),
                            "novelty_hash": ld.get("novelty_hash", "")[:12],
                        }
                        recent_lessons.append(summary_entry)
                        if ld.get("lesson_type") == "OPPORTUNITY_CANDIDATE":
                            opportunity_candidates.append({
                                "lesson_id": ld.get("lesson_id"),
                                "title": ld.get("title"),
                                "status": ld.get("status", "DISCOVERED"),
                                "idea_sync_id": ld.get("idea_sync_id"),
                                "evidence": ld.get("evidence"),
                                "revenue_evidence": "NOT_VERIFIED",
                            })

            # Collect latest evaluations (bounded to 10)
            evals_dir = academy_dir / "evaluations"
            recent_evals = []
            if evals_dir.exists():
                efiles = sorted(evals_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
                for ef in efiles[:10]:
                    ed = load_json_safe(ef)
                    if ed and "evaluation_id" in ed:
                        recent_evals.append({
                            "evaluation_id": ed.get("evaluation_id"),
                            "lesson_id": ed.get("lesson_id"),
                            "verdict": ed.get("verdict", "UNKNOWN"),
                            "metrics": ed.get("metrics", {}),
                            "evaluated_at": ed.get("evaluated_at"),
                        })

            academy_data = {
                "config": config_data,
                "economics": econ_data,
                "lessons": recent_lessons,
                "opportunities": opportunity_candidates,
                "evaluations": recent_evals,
            }

        # Read SNITCH state and recent incidents
        snitch_file = states_dir / "agent-snitch.json"
        snitch_data = load_json_safe(snitch_file) if snitch_file.exists() else None

        incidents_data = []
        if runtime_alerts_dir.exists():
            alert_files = sorted(runtime_alerts_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
            for af in alert_files[:10]:
                ad = load_json_safe(af)
                if ad and "message_id" in ad:
                    incidents_data.append({
                        "message_id": ad.get("message_id"),
                        "incident_id": ad.get("incident_id"),
                        "classification": ad.get("classification"),
                        "severity": ad.get("severity", "MEDIUM"),
                        "status": ad.get("status", "OPEN"),
                        "task_id": ad.get("task_id"),
                        "workflow_id": ad.get("workflow_id"),
                        "correlation_id": ad.get("correlation_id"),
                        "reason": ad.get("reason"),
                        "created_at": ad.get("created_at"),
                    })

        # Read 8 Bodyguards reserve states
        try:
            bodyguards_data = BodyguardPoolManager(COURIER_DIR).get_all_bodyguards()
        except Exception:
            bodyguards_data = []

        response_data = {
            "schema_version": "2.0",
            "server_time": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "agents": agents_data,
            "counts": counts,
            "context_snapshot": snapshot_data,
            "academy": academy_data,
            "snitch": snitch_data,
            "bodyguards": bodyguards_data,
            "incidents": incidents_data,
            "runtime_alert": latest_runtime_alert,
            "treasury": treasury,
            "bus": {
                "is_locked": is_locked,
                "active_lock": active_lock_name,
                "last_decision": last_decision,
                "active_workflow": active_lock_name or "IDLE_MONITORING",
                "correlation_id": derived_correlation_id,
                "human_gate": human_gate_active,
                "active_human_gate": active_human_gate,
                "gate_decision": gate_decision,
                "context_version": snapshot_data.get("context_version") if snapshot_data else 0,
                "snapshot_hash": snapshot_data.get("snapshot_hash") if snapshot_data else "NONE",
            }
        }


        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(response_data).encode("utf-8"))

    def handle_submit_idea(self):
        content_len = int(self.headers.get("Content-Length", 0))
        post_body = self.rfile.read(content_len).decode("utf-8")
        try:
            req_data = json.loads(post_body)
            idea = req_data.get("idea", "").strip()
            idea_type = req_data.get("type", "IDEA")

            if not idea:
                self.send_error(400, "Empty idea provided")
                return

            def run_async_chief():
                chief = ChiefCommander(repo_dir=COURIER_DIR)
                chief.execute_human_idea(idea, idea_type)

            threading.Thread(target=run_async_chief, daemon=True).start()

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "INGESTED",
                "message": f"Human {idea_type} received by Chief Commander and workflow dispatched.",
                "idea": idea,
            }).encode("utf-8"))

        except Exception as exc:
            self.send_error(500, f"Failed to ingest idea: {exc}")

    def handle_human_gate(self):
        content_len = int(self.headers.get("Content-Length", 0))
        post_body = self.rfile.read(content_len).decode("utf-8")
        try:
            req_data = json.loads(post_body)
            action = req_data.get("action", "").upper()  # "APPROVE" or "REJECT"
            workflow_id = _nonempty_text(req_data.get("workflow_id"))
            correlation_id = _nonempty_text(req_data.get("correlation_id"))
            reason = req_data.get("reason", "Operator decision from Visual Studio Cockpit")

            if action not in ["APPROVE", "REJECT"]:
                self.send_error(400, "Invalid action. Must be APPROVE or REJECT.")
                return

            active_gate = find_active_human_gate(
                load_agent_states(EVENTS_DIR / "agent-states")
            )
            if not active_gate or not active_gate.get("provenance_complete"):
                self.send_error(409, "Human gate has no verified workflow/correlation provenance.")
                return
            if (
                workflow_id != active_gate["workflow_id"]
                or correlation_id != active_gate["correlation_id"]
            ):
                self.send_error(409, "Human gate provenance mismatch.")
                return

            approval_id = f"appr-{uuid.uuid4().hex[:8]}"
            approval_record = {
                "schema_version": "2.0",
                "approval_id": approval_id,
                "action": action,
                "decision": action,
                "workflow_id": workflow_id,
                "task_id": active_gate.get("task_id"),
                "correlation_id": correlation_id,
                "operator": "HUMAN_OPERATOR",
                "reason": reason,
                "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            }

            approval_file = APPROVALS_DIR / f"{approval_id}.json"
            save_json_safe(approval_file, approval_record)
            print(f"\n[SERVER] Human Gate Event Persisted: {action} for {workflow_id} ({approval_id})")

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "PERSISTED",
                "approval_id": approval_id,
                "action": action,
                "workflow_id": workflow_id,
            }).encode("utf-8"))

        except Exception as exc:
            self.send_error(500, f"Failed to persist human gate action: {exc}")

    def handle_trigger_workflow(self):
        def run_async():
            chief = ChiefCommander(repo_dir=COURIER_DIR)
            chief.execute_human_idea("Demo-Lauf: Optimiere Video-Pipeline und prüfe Channel-Konfigurationen", "GOAL")

        threading.Thread(target=run_async, daemon=True).start()

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps({"status": "TRIGGERED", "message": "Demo workflow started in background"}).encode("utf-8"))

    def handle_trigger_demo(self):
        def run_async_demo():
            from run_demo_workflow import DemoOrchestrator
            orchestrator = DemoOrchestrator(repo_dir=COURIER_DIR)
            orchestrator.reset_demo_environment()
            orchestrator.run_live_demo()

        threading.Thread(target=run_async_demo, daemon=True).start()

        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps({"status": "TRIGGERED", "message": "Deterministic live demo workflow started in background"}).encode("utf-8"))


def run_server(port: int = 8088):
    server_address = ("", port)
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(server_address, StudioHTTPRequestHandler) as httpd:
        print(f"=== AUTONOMOUS CHIEF OPERATIONS COCKPIT RUNNING ===")
        print(f"Serving at: http://localhost:{port}")
        print(f"Studio Root: {STUDIO_DIR}")
        print(f"Courier Bus: {EVENTS_DIR}")
        print("Press Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down Operations Studio server.")


def main():
    parser = argparse.ArgumentParser(description="Run Autonomous Chief Operations Cockpit Server")
    parser.add_argument("--port", type=int, default=8088, help="Port to serve UI (default: 8088)")
    args = parser.parse_args()
    run_server(args.port)


if __name__ == "__main__":
    main()
